import matplotlib.pyplot as plt
import serial
import time

ser = serial.Serial(
    port='/dev/ttyACM0', \
    baudrate=9600, \
    parity=serial.PARITY_NONE, \
    stopbits=serial.STOPBITS_ONE, \
    bytesize=serial.EIGHTBITS, \
    timeout=0)

print("connected to: " + ser.portstr)

# this will store the line
counter = 0
data = []
strNum = ""
f = open("PCM.txt", "w")
file_samples = 0
while True:
    for c in ser.read():
        strNum += chr(c)  # convert from ANSII
        break
    counter += 1

    # print(strNum)
    try:
        # print(len(list(map(int, strNum.split(',')))))
        if len(list(map(int, strNum.split(',')))) == 64:
            # data.append()
            # fig, ax = plt.subplots()
            f.write(strNum + "\n")
            file_samples += 1
            # print(len(list(map(int, strNum.split(', ')))))
            # ax.plot(list(map(int, strNum.split(', '))), '-')
            # plt.show()
            print(file_samples)
            if file_samples == 50:
                f.close()
                break
            strNum = ""
    except:
        pass
    counter = 0

ser.close()
